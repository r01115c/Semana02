package tareasemana02;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculoSueldo extends javax.swing.JFrame {


    public CalculoSueldo() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtHorasTrabajadas = new javax.swing.JTextField();
        txtNumeroHijos = new javax.swing.JTextField();
        btnCalcular = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtResultado = new javax.swing.JTextArea();
        cboTarifaHoraria = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "CALCULO DE SUELDO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        txtHorasTrabajadas.setBorder(javax.swing.BorderFactory.createTitledBorder("Horas Trabajadas:"));

        txtNumeroHijos.setBorder(javax.swing.BorderFactory.createTitledBorder("Numero de Hijos:"));

        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        txtResultado.setColumns(20);
        txtResultado.setRows(5);
        jScrollPane1.setViewportView(txtResultado);

        cboTarifaHoraria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione:", "A", "B" }));
        cboTarifaHoraria.setBorder(javax.swing.BorderFactory.createTitledBorder("Tarifa Horaria"));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(btnCalcular)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnNuevo)
                .addGap(21, 21, 21))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboTarifaHoraria, 0, 151, Short.MAX_VALUE)
                    .addComponent(txtNumeroHijos)
                    .addComponent(txtHorasTrabajadas))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(txtHorasTrabajadas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cboTarifaHoraria, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtNumeroHijos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCalcular)
                    .addComponent(btnNuevo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
         try {
        double horas = Double.parseDouble(txtHorasTrabajadas.getText());
        int tarifaIndex = cboTarifaHoraria.getSelectedIndex();

        // Validar que se haya seleccionado una tarifa
        if (tarifaIndex == 0) {
            txtResultado.setText("Por favor, seleccione una tarifa válida.");
            return;
        }

        double tarifa = tarifaIndex == 1 ? 45.0 : 37.5; // Tarifa A o B
        int hijos = Integer.parseInt(txtNumeroHijos.getText());

        // Cálculo del sueldo base
        double sueldoBase = horas * tarifa;

        // Cálculo de la bonificación por hijos
        double bonoHijos = 0;
        if (hijos <= 3) {
            bonoHijos = hijos * 40.5;
        } else {
            bonoHijos = (3 * 40.5) + ((hijos - 3) * 35.0);
        }

        // Sueldo bruto
        double sueldoBruto = sueldoBase + bonoHijos;

        // Cálculo del descuento
        double descuento = sueldoBruto > 3500 ? 0.135 : 0.10; // 13.5% o 10%
        double montoDescuento = sueldoBruto * descuento;
        double sueldoNeto = sueldoBruto - montoDescuento;

        // Mostrar resultados
        txtResultado.setText("Sueldo Base: " + sueldoBase + "\nBono por Hijos: " + bonoHijos + 
                              "\nSueldo Bruto: " + sueldoBruto + "\nDescuento: " + montoDescuento + 
                              "\nSueldo Neto: " + sueldoNeto);
    } catch (NumberFormatException e) {
        txtResultado.setText("Por favor, ingrese valores válidos.");
    }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        txtHorasTrabajadas.setText("");
        cboTarifaHoraria.setSelectedIndex(0); // Reiniciar a la primera opción
        txtNumeroHijos.setText("");
        txtResultado.setText("");
    }//GEN-LAST:event_btnNuevoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CalculoSueldo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cboTarifaHoraria;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtHorasTrabajadas;
    private javax.swing.JTextField txtNumeroHijos;
    private javax.swing.JTextArea txtResultado;
    // End of variables declaration//GEN-END:variables
}
