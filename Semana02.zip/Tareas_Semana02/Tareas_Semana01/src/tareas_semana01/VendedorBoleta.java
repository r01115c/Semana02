package tareas_semana01;

import java.util.Scanner;

public class VendedorBoleta {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Datos iniciales
        double sueldoBasico = 350.75;
        double porcentajeComision = 0.05;
        double porcentajeDescuento = 0.15;
        
        // Entrada: Importe total vendido
        System.out.print("Ingrese el importe total vendido en el mes: S/ ");
        double totalVendido = sc.nextDouble();
        
        // Cálculos
        double comision = totalVendido * porcentajeComision;
        double sueldoBruto = sueldoBasico + comision;
        double descuento = sueldoBruto * porcentajeDescuento;
        double sueldoNeto = sueldoBruto - descuento;
        
        // Salida: Boleta de pago
        System.out.println("\n--- Boleta de Pago del Vendedor ---");
        System.out.println("Sueldo basico: S/ " + sueldoBasico);
        System.out.println("Comision: S/ " + comision);
        System.out.println("Sueldo bruto: S/ " + sueldoBruto);
        System.out.println("Descuento (15%): S/ " + descuento);
        System.out.println("Sueldo neto: S/ " + sueldoNeto);
    }
}
